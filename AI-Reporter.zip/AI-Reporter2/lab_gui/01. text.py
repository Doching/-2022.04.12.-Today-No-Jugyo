import streamlit as st

st.title('Title')
st.text('본문')
st.text('본문2')